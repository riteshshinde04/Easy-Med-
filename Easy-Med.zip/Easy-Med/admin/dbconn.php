<?php
$conn = mysqli_connect("localhost","root","Ankit123456#","transplant");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>
