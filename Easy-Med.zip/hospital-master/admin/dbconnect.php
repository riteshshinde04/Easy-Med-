<?php
$con = mysqli_connect("localhost","root","Ankit123456#","donation");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>
